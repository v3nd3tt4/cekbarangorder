<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Dashboard </title>
    <!-- <link rel="shortcut icon" href="<?php echo base_url(); ?>assets/images/Logo_IAIN_Raden_Intan_Bandar_Lampung.png"/> -->
    <link href="<?=base_url()?>assets/assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/assets/font-awesome/css/font-awesome.css" rel="stylesheet">

    <!-- Style graph -->
    <link href="<?=base_url()?>assets/assets/css/plugins/morris/morris-0.4.3.min.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/assets/css/plugins/chartist/chartist.min.css" rel="stylesheet">

    <link href="<?=base_url()?>assets/assets/css/animate.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/jquery.bxslider.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/assets/css/style.css" rel="stylesheet">
    
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/dataTable/css/dataTables.bootstrap.css"/>
</head>
<body>
    <div id="wrapper">